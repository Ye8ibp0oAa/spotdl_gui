from setuptools import setup

# This will read the metadata from pyproject.toml
setup()